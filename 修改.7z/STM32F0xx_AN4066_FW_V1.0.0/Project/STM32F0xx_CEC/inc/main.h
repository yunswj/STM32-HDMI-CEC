#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C"
{
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm320518_eval_lcd.h"
#include "stm320518_eval_cec.h"

#include "cec_display.h"
#include <stdio.h>
#include <stdlib.h>
#include "stm320518_eval.h"
#include "stm32f0xx_it.h"

#ifdef __cplusplus
}
#endif

#endif