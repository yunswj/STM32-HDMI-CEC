#include "main.h"
int main(void)
{
  /* Initialize the CEC Demo */
  CEC_Display_Init();

  /* Infinite loop */
  while (1)
  {
    CEC_Display_CECAvailableCommands();
  }
}
#ifdef USE_FULL_ASSERT
/**
 * @brief  报告源文件名和源行号发生assert_param 错误的地方。
 * @param  file: 指向源文件名的指针
 * @param  line: assert_param 错误行源号
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* 用户可以添加自己的实现来报告文件名和行号，
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif
